<?php
/**
 * Plugin Name: Simple Stock Market Chart
 * Plugin URI: https://www.example.com/my-stock-chart-plugin
 * Description: A plugin to display stock charts using AlphaVantage API and Chart.js.
 * Version: 1.0.0
 * Author: Miłosz Głódkowski
 * Author URI: https://www.example.com
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: my-stock-chart-plugin
 */
 


function my_theme_enqueue_scripts() {
    // Enqueue Chart.js from CDN
    wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js@3.7.1', array(), '3.7.1', true);

    // Enqueue chart-js-adapter-date-fns from CDN
    wp_enqueue_script('chart-js-adapter-date-fns', 'https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns@3.0.0', array('chart-js'), '3.0.0', true);


  // Enqueue the my-chart script
    wp_enqueue_script('my-chart', plugin_dir_url(__FILE__) . 'my-chart.js', array('chart-js', 'chart-js-adapter-date-fns', 'jquery'), '1.0.0', true);

    // Localize data for Ajax
    wp_localize_script('my-chart', 'verta', array(
        'ajax_url' => admin_url('admin-ajax.php'),
		'plugin_url' => plugin_dir_url(__FILE__)

));
}
add_action('wp_enqueue_scripts', 'my_theme_enqueue_scripts');
//DEBUGGGING

function log_message($message) {
    $log_message = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
    file_put_contents(plugin_dir_path(__FILE__) . '/data/cron_debug.log', $log_message, FILE_APPEND);
}


//END DEBUGGING
     //cron scripts
function update_stock_data_cron_schedule() {
    if (!wp_next_scheduled('update_stock_data_daily')) {
		$start_time = strtotime('tomorrow 7:00 PM');
        wp_schedule_event($start_time, 'daily', 'update_stock_data_daily');
    }
}
add_action('wp', 'update_stock_data_cron_schedule');

function update_stock_data($symbol) {
    // Fetch stock data from AlphaVantage API
	  $options = get_option('my_stock_chart_plugin_options');
    $api_key = isset($options['api_key']) ? $options['api_key'] : '';
	
	    log_message("Fetching stock data for symbol: {$symbol}");

    $json = file_get_contents('https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=' . $symbol . '&apikey=' . $api_key);
    
    // Save the fetched data to a file (e.g., stock_data.json) in your theme folder
    $file_path = plugin_dir_path(__FILE__) .  '/data/stock_data_' . $symbol . '.json';
    file_put_contents($file_path, $json);
	
	log_message("Saved stock data for symbol: {$symbol}");
}


function update_stock_data_cron() {
	  log_message('Executing update_stock_data from WP cron');
    $symbols = get_option('stock_chart_symbols', array());
    log_message('Symbols: ' . implode(', ', $symbols));

    foreach ($symbols as $symbol) {
        update_stock_data($symbol);
    }
}
add_action('update_stock_data_daily', 'update_stock_data_cron');

// Add custom cron schedule for every minute FOR TESTING
//function custom_cron_schedules($schedules) {
  //  $schedules['every_minute'] = array(
    //    'interval' => 60, // 60 seconds
     //   'display' => __('Every Minute')
   // );
   // return $schedules;
//}
//add_filter('cron_schedules', 'custom_cron_schedules');
     //END cron scripts




//FETCH DATA FROM FILE
function get_stock_data() {
    $symbol = isset($_POST['symbol']) ? sanitize_text_field($_POST['symbol']) : 'IBM';
	$file_path = plugin_dir_path(__FILE__) .  ' /data/stock_data_' . $symbol . '.json';
	
	$json = file_get_contents($file_path);
    $data = json_decode($json, true);

    $timeSeries = $data['Time Series (Daily)'];
    $labels = array_keys($timeSeries);
    $prices = array_map(function($dayData) {
        return $dayData['4. close'];
    }, $timeSeries);

    $stockData = array(
        'labels' => $labels,
        'prices' => $prices
    );
    
    echo json_encode($stockData);
    wp_die();
}
add_action('wp_ajax_get_stock_data', 'get_stock_data');
add_action('wp_ajax_nopriv_get_stock_data', 'get_stock_data');

//END FETCHING


//GENERATE THE SHORTCODE AND RUN MY-CHART.JS
function generate_stock_chart_shortcode($atts) {
    $atts = shortcode_atts(array('symbol' => 'IBM'), $atts, 'stock_chart');
    $symbol = $atts['symbol'];
	
	$symbols = get_option('stock_chart_symbols', array());
	if (!in_array($symbol, $symbols)) {
		$symbols[] = $symbol;
		update_option('stock_chart_symbols', $symbols);
		
		update_stock_data($symbol);
		
	}

    ob_start();
    ?>
    <div class="stock-chart-container" data-symbol="<?php echo $symbol; ?>">
        <canvas id="stock-chart-<?php echo $symbol; ?>" width="400" height="200"></canvas>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('stock_chart', 'generate_stock_chart_shortcode');

//END GENERATE 
function my_stock_chart_plugin_settings_menu() {
    add_options_page(
        'Simple Stock Market Chart Settings',
        'Simple Stock Market Chart',
        'manage_options',
        'simple-stock-market-chart',
        'my_stock_chart_plugin_settings_page'
    );
}
add_action('admin_menu', 'my_stock_chart_plugin_settings_menu');


function my_stock_chart_plugin_settings_page() {
    ?>
    <div class="wrap">
        <h1>Simple Stock Market Chart Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('my_stock_chart_plugin_options');
            do_settings_sections('simple-stock-market-chart');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}


function my_stock_chart_plugin_settings_init() {
    register_setting('my_stock_chart_plugin_options', 'my_stock_chart_plugin_options');

    add_settings_section(
        'my_stock_chart_plugin_settings_section',
        'API Settings',
        'my_stock_chart_plugin_settings_section_callback',
        'simple-stock-market-chart'
    );

    add_settings_field(
        'api_key',
        'API Key',
        'my_stock_chart_plugin_settings_api_key_callback',
        'simple-stock-market-chart',
        'my_stock_chart_plugin_settings_section'
    );
}
add_action('admin_init', 'my_stock_chart_plugin_settings_init');


function my_stock_chart_plugin_settings_section_callback() {
    echo 'Enter your AlphaVantage API key:';
}

function my_stock_chart_plugin_settings_api_key_callback() {
    $options = get_option('my_stock_chart_plugin_options');
    $api_key = isset($options['api_key']) ? $options['api_key'] : '';
    echo "<input type='text' name='my_stock_chart_plugin_options[api_key]' value='{$api_key}' size='40'>";
}


//SETTINGS PAGE