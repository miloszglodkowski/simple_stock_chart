console.log("my-chart.js is running");
jQuery(document).ready(function ($) {
	
    $(".stock-chart-container").each(function () {
        const container = $(this);
        const symbol = container.data("symbol");

        // Fetch stock data using JSON
        const jsonFilePath = verta.plugin_url + "/data/stock_data_" + symbol + ".json";

        $.getJSON(jsonFilePath, function (data) {
           

            let stockData = {
                labels: Object.keys(data["Time Series (Daily)"]),
                prices: Object.values(data["Time Series (Daily)"]).map(function (dayData) {
                    return dayData["4. close"];
                }),
            };
            renderStockChart(stockData, symbol, container);
        }).fail(function (jqxhr, textStatus, error) {
            console.log("Error fetching stock data:", textStatus, error);
        });
    });

    function renderStockChart(stockData, symbol, container) {
        const canvas = container.find("canvas")[0];
        let ctx = canvas.getContext("2d");
        new Chart(ctx, {
            type: "line",
            data: {
                labels: stockData.labels,
                datasets: [
                    {
                        label: symbol + " Notowania",
                        data: stockData.prices,
                        borderColor: "rgba(75, 192, 192, 1)",
                        borderWidth: 2,
                    },
                ],
            },
            options: {
                scales: {
                    x: {
                        type: "time",
                        time: {
                            unit: "day",
                        },
                    },
                },
            },
        });
    }
});
